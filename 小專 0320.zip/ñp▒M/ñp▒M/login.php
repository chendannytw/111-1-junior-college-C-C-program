<!--處理登入 (login.php)這段程式碼用來驗證用戶登錄資訊。-->
<?php  
// login.php  
session_start();  
include 'db.php';  

if ($_SERVER["REQUEST_METHOD"] == "POST") {  
    $username = $_POST['username'];  
    $password = $_POST['password'];  

    // 從資料庫中獲取使用者資料  
    $stmt = $conn->prepare("SELECT password FROM users WHERE username = ?");  
    $stmt->bind_param("s", $username);  
    $stmt->execute();  
    $stmt->bind_result($hashed_password);  
    $stmt->fetch();  
    
    // 檢查密碼  
    if (password_verify($password, $hashed_password)) {  
        $_SESSION['username'] = $username; // 設定 Session  
        echo "登入成功！歡迎回來，" . htmlspecialchars($username) . "。";  
        // 可以在這裡重定向到會員中心或其他頁面  
    } else {  
        echo "登入失敗，請檢查您的使用者名稱或密碼。";  
    }  

    $stmt->close();  
}  
$conn->close();  
?>  