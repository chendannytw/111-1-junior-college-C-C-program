<?php  
// db.php  
$servername = "localhost"; // 資料庫伺服器  
$username = "root"; // 資料庫使用者  
$password = ""; // 資料庫密碼  
$dbname = "medical_aids"; // 資料庫名稱  

// 建立連接  
$conn = new mysqli($servername, $username, $password, $dbname);  

// 檢查連接  
if ($conn->connect_error) {  
    die("連接失敗: " . $conn->connect_error);  
}  
?>  