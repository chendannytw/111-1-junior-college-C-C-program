<!--處理註冊 (register.php)這段程式碼用來處理用戶註冊的請求，並將資料儲存到資料庫中。-->
<?php  
// register.php  
include 'db.php';  

if ($_SERVER["REQUEST_METHOD"] == "POST") {  
    $username = $_POST['username'];  
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT); // 安全地雜湊密碼  
    $email = $_POST['email'];  

    // 檢查使用者是否已存在  
    $stmt = $conn->prepare("SELECT * FROM users WHERE username = ?");  
    $stmt->bind_param("s", $username);  
    $stmt->execute();  
    $result = $stmt->get_result();  

    if ($result->num_rows > 0) {  
        echo "該使用者名稱已被使用。";  
    } else {  
        // 插入新用戶  
        $stmt = $conn->prepare("INSERT INTO users (username, password, email) VALUES (?, ?, ?)");  
        $stmt->bind_param("sss", $username, $password, $email);  
        
        if ($stmt->execute()) {  
            echo "註冊成功！請登入。";  
            header('Location: login.html'); // 註冊成功後重定向到登入頁面  
            exit();  
        } else {  
            echo "註冊失敗。請稍後再試。";  
        }  
    }  

    $stmt->close();  
}  
$conn->close();  
?>  